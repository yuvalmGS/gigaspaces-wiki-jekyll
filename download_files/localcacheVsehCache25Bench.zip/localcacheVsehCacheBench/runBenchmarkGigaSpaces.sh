#!/bin/bash

. setExampleEnv.sh

$JAVA_HOME/bin/java -Duseehcache=false -cp ./bin:$GS_JARS:ehcache-1.4.1.jar:backport-util-concurrent-java12-3.1.jar localcachebench.LocalCacheVsEHCacheBenchmarkMain
