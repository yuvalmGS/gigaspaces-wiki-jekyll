#!/bin/bash

. setExampleEnv.sh

$JAVA_HOME/bin/java -Duseehcache=true -cp ./bin:$GS_JARS:ehcache-core-2.5.0.jar:ehcache-terracotta-2.5.0.jar:slf4j-api-1.6.1.jar:slf4j-jdk14-1.6.1.jar:terracotta-toolkit-1.4-runtime-4.0.0.jar localcachebench.LocalCacheVsEHCacheBenchmarkMain
