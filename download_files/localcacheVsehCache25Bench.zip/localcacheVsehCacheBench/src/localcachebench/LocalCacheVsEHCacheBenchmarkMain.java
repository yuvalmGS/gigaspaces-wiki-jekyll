package localcachebench;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import net.sf.ehcache.store.MemoryStoreEvictionPolicy;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.space.UrlSpaceConfigurer;
import org.openspaces.core.space.cache.LocalCacheSpaceConfigurer;

import com.j_spaces.core.IJSpace;
import com.j_spaces.core.client.UpdateModifiers;

public class LocalCacheVsEHCacheBenchmarkMain {

	static boolean useEHCache = true;
	static int maxThreads = 2;
	static GigaSpace gigaSpaceProxy;
	static ExecutorService threadExecutor;
	static CacheManager cacheManager = null;
	static Cache cache = null;
	static GigaSpace spaceServer;
	static int readIterations = 1000;
	static int maxKeys = 100;
	static int totalThreads = 8;

	public static void main(String[] args) throws Exception {
		useEHCache = Boolean.valueOf(System.getProperty("useehcache", "false"))
				.booleanValue();
		if (useEHCache) {
			cacheManager = CacheManager.create();
			Cache testCache = new Cache("myCache", 5000,
					MemoryStoreEvictionPolicy.LRU, false, "", true, 6000, 6000,
					false, 0, null);
			cacheManager.addCache(testCache);
			cache = cacheManager.getCache("myCache");
			System.out.println("Terracotta ehCache benchmark started!");
		} else {
			spaceServer = new GigaSpaceConfigurer(new UrlSpaceConfigurer(
					"/./mySpace")).gigaSpace();

			UrlSpaceConfigurer urlSpaceConfigurer = new UrlSpaceConfigurer(
					"jini://*/*/mySpace");
			IJSpace localSpaceProxy = new LocalCacheSpaceConfigurer(
					urlSpaceConfigurer.space()).localCache();
			gigaSpaceProxy = new GigaSpaceConfigurer(localSpaceProxy)
					.gigaSpace();
			gigaSpaceProxy.getSpace().setUpdateModifiers(UpdateModifiers.UPDATE_OR_WRITE | UpdateModifiers.NO_RETURN_VALUE);
			System.out.println("GigaSpaces cache benchmark started!");
		}
		// pushing data into cache/space
		for (int i = 0; i < maxKeys; i++) {
			TestClass t = new TestClass(i);
			if (useEHCache) {
				Element e = new Element(new Integer(i), t);
				cache.put(e);
			} else {
				gigaSpaceProxy.write(t);
			}
		}

		threadExecutor = Executors.newFixedThreadPool(totalThreads);
		Task[] tasks = new Task[totalThreads];
		for (int t = 0; t < totalThreads; t++) {
			tasks[t] = new Task();
			maxThreads = t + 1;
			threadExecutor.execute(tasks[t]);
			Thread.sleep(10000);

			// calculate average TP
			long avgTP=0;

			for (int c = 0; c < maxThreads; c++) {
				avgTP = avgTP + tasks[c].curTP ;
				tasks[c].curTP = 0;
			}
			avgTP = avgTP / maxThreads;
			System.out.println("--------- Average TP for all "+maxThreads + " threads:"  + avgTP + " read/sec---------------------");
		}
		Thread.sleep(5000);
		System.out.println("--------- Exit Demo --------------");
		System.exit(0);
	}

	static class Task implements Runnable {
		public Task() {
		}

		public long curTP = 0;

		@Override
		public void run() {
			System.out.println(maxThreads + " Client threads started");

			int statCount = 0;
			while (true) {
				if (useEHCache) {
					long startTime = System.currentTimeMillis();
					for (int i = 0; i < readIterations; i++) {
						for (int k = 0; k < maxKeys; k++) {
							if (cache.get(new Integer(k)) == null) {
								System.out.println("No object found " + i);
							}
						}
					}
					long endTime = System.currentTimeMillis();
					long readDuration = (endTime - startTime);
					long tp = 1000 * (readIterations * maxKeys)
							/ (readDuration);
					curTP = (curTP + tp) / 2;
					statCount++;
//					if (statCount % 50 == 0)
//						System.out.println("Total client Threads:" + maxThreads+ " read TP[read/sec]:" + curTP);
				} else {
					long startTime = System.currentTimeMillis();
					for (int i = 0; i < readIterations; i++) {
						for (int k = 0; k < maxKeys; k++) {
							if (gigaSpaceProxy.readById(TestClass.class,
									new Integer(k)) == null) {
								System.out.println("No object found " + i);
							}
						}
					}
					long endTime = System.currentTimeMillis();
					long readDuration = (endTime - startTime);
					long tp = 1000 * (readIterations * maxKeys)
							/ (readDuration);
					curTP = (curTP + tp) / 2;
					statCount++;
//					if (statCount % 50 == 0)
//						System.out.println("Total client Threads:" + maxThreads+ " read TP[read/sec]:" + curTP);
				}
			}
		}
	}
}
