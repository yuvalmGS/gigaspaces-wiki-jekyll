
#!/bin/bash
export JSHOMEDIR=/mnt/export/linux2/shay/xap8.0.4/gigaspaces-xap-premium-8.0.4-ga

. $JSHOMEDIR/bin/setenv.sh

